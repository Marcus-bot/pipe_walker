#ifndef __EXTI_H
#define __EXTI_H
#include <sys.h>
void myEXTI1_Init(void);
#endif
