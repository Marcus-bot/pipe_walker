#include<control.h>
#include<timer.h>
#include<MPU6050.h>
#include<delay.h>
#include<LED.h>
#define dir1 (-1)
#define dir2 (-1)
#define dir3 (-1)
#define dir4 (-1)
#define dir5 (1)
#define dir6 (1)
#define dir7 (1)
#define dir8 (1)


short standPWM=150;

u8 MAX = 100;

PID PID_ROL, PID_PIT;
float moto1 = 0, moto2 = 0, moto3 = 0, moto4 = 0;
float T;
float test1,test2,test3;
void Motor_Init()
{
	myTIMER3_PWM_Init(1999,719);			//����2000�Σ�720��Ƶ��20ms
	myTIMER1_PWM_Init(1999,719);			//����2000�Σ�720��Ƶ��20ms	
	Motor1_set(0);
	Motor2_set(0);
	Motor3_set(0);
	Motor4_set(0);
	Motor5_set(0);
	Motor6_set(0);
	Motor7_set(0);
	Motor8_set(0);
	delay_ms(1000);
	delay_ms(1000);
	delay_ms(500);
	delay_ms(1000);
	delay_ms(1000);
	

}

void Motor1_set(short speed)//dir������Ҷ��ȡֵforward��backward,speed�����������Ʒ���
{
	if(speed >= MAX)
		speed = MAX;
	if(speed <= (-1)*MAX)
		speed = (-1)*MAX;
	TIM_SetCompare1(TIM3,standPWM+dir1*speed);
	test1 = standPWM+dir1*speed;
	
}

void Motor2_set(short speed)
{
	if(speed >= MAX)
		speed = MAX;
	if(speed <= (-1)*MAX)
		speed = (-1)*MAX;
	TIM_SetCompare2(TIM3,standPWM+dir2*speed);
}

void Motor3_set(short speed)
{
	if(speed >= MAX)
		speed = MAX;
	if(speed <= (-1)*MAX)
		speed = (-1)*MAX;
	TIM_SetCompare3(TIM3,standPWM+0+dir3*speed);
}

void Motor4_set(short speed)
{
	if(speed >= MAX)
		speed = MAX;
	if(speed <= (-1)*MAX)
		speed = (-1)*MAX;
	TIM_SetCompare4(TIM3,standPWM+dir4*speed);
}

void Motor5_set(short speed)
{
	if(speed >= MAX)
		speed = MAX;
	if(speed <= (-1)*MAX)
		speed = (-1)*MAX;
	TIM_SetCompare1(TIM1,standPWM+dir5*speed);
}

void Motor6_set(short speed)
{
	if(speed >= MAX)
		speed = MAX;
	if(speed <= (-1)*MAX)
		speed = (-1)*MAX;
	TIM_SetCompare2(TIM1,standPWM+dir6*speed);
}

void Motor7_set(short speed)
{
	if(speed >= MAX)
		speed = MAX;
	if(speed <= (-1)*MAX)
		speed = (-1)*MAX;
	TIM_SetCompare3(TIM1,standPWM+dir7*speed);
}

void Motor8_set(short speed)
{
	if(speed >= MAX)
		speed = MAX;
	if(speed <= (-1)*MAX)
		speed = (-1)*MAX;
	TIM_SetCompare4(TIM1,standPWM+dir8*speed);
}

void Motor_1234(u8 UD,u8 speed)//1��Ǳ2�ϸ�0����
{
	signed char M1y,M2y,M3y,M4y;
	switch (UD){
		case 0: {M1y=0;M2y=0;M3y=0;M4y=0;break;}
		case 1: {M1y=1;M2y=1;M3y=1;M4y=1;break;}
		case 2: {M1y=(signed char)(-1);M2y=(signed char)(-1);M3y=(signed char)(-1);M4y=(signed char)(-1);break;}
	}
	Motor1_set(M1y*speed+moto1);
	Motor2_set(M2y*speed+moto2);
	Motor3_set(M3y*speed+moto3);
	Motor4_set(M4y*speed+moto4);
	//test2 = M1y*speed+moto1;
}


void Motor_5678(u8 FB, u8 speed1, u8 LR, u8 speed2)//1ǰ��2����0������1��ת2��ת0����
{
	signed char M5x,M6x,M7x,M8x;//������
	signed char M5z,M6z,M7z,M8z;//������
	switch (FB){
		case 0: {M5x=0;M6x=0;M7x=0;M8x=0;break;}
		case 1: {M5x=1;M6x=1;M7x=(signed char)(-1);M8x=(signed char)(-1);break;}
		case 2: {M5x=(signed char)(-1);M6x=(signed char)(-1);M7x=1;M8x=1;break;}
	}
	switch (LR){
		case 0: {M5z=0;M6z=0;M7z=0;M8z=0;break;}
		case 1: {M5z=(signed char)(-1);M6z=1;M7z=(signed char)(-1);M8z=1;break;}
		case 2: {M5z=1;M6z=(signed char)(-1);M7z=1;M8z=(signed char)(-1);break;}
	}
	Motor5_set(M5x*speed1+M5z*speed2);
	Motor6_set(M6x*speed1+M6z*speed2);
	Motor7_set(M7x*speed1+M7z*speed2);
	Motor8_set(M8x*speed1+M8z*speed2);
}

void PID_Init()
{
	//ROLL
	PID_ROL.Kp=1.0;
	PID_ROL.Ti=30000;
	PID_ROL.Td=0.8;
	PID_ROL.Ek=0;
	PID_ROL.Ek_1=0;
	PID_ROL.Ek_2=0;
	PID_ROL.DOUT=0;
	PID_ROL.OUT=0;
	//PITCH
	PID_PIT.Kp=0.7;
	PID_PIT.Ti=30000;
	PID_PIT.Td=0.8;
	PID_PIT.Ek=0;
	PID_PIT.Ek_1=0;
	PID_PIT.Ek_2=0;
	PID_PIT.DOUT=0;
	PID_ROL.OUT=0;
	T = 40;
}

void getMxMi(float* moto)
{
	if(*moto>=(float)100) *moto = (float)100;
	if(*moto<=(float)(-100)) *moto = (float)(-100);
}


void PID_Calc(float roll, float pitch, u8* pidcal20ms)
{
	float dk1,dk2;
	float t1=0,t2=0,t3=0;
	float t1max = 25;
	if((*pidcal20ms*20)<T) return ;
	
	
	//ROLL
	PID_ROL.Ek = 0 - roll;
	dk1=PID_ROL.Ek-PID_ROL.Ek_1;
	dk2=PID_ROL.Ek-2*PID_ROL.Ek_1-PID_ROL.Ek_2;
//	t1 = PID_ROL.Ek*PID_ROL.Kp*T/PID_ROL.Ti;//������
	t2 = dk2*PID_ROL.Kp*PID_ROL.Td/T;		//΢����
	t3 = dk1*PID_ROL.Kp;					//������
	if(t1>=t1max){
		t1 = t1max;
	}
	if(t1<=(-1)*t1max){
		t1 = (-1)*t1max;
	}
	PID_ROL.DOUT =t1+t2+t3;
	PID_ROL.Ek_2=PID_ROL.Ek_1;
	PID_ROL.Ek_1=PID_ROL.Ek;
	
	//PITCH
	PID_PIT.Ek = 0 - pitch;
	dk1=PID_PIT.Ek-PID_PIT.Ek_1;
	dk2=PID_PIT.Ek-2*PID_PIT.Ek_1-PID_PIT.Ek_2;
//	t1 = PID_PIT.Ek*PID_PIT.Kp*T/PID_PIT.Ti;
	t2 = dk2*PID_PIT.Kp*PID_PIT.Td/T;
	t3 = dk1*PID_PIT.Kp;						
	if(t1>=t1max){
		t1 = t1max;
	}
	if(t1<=(-1)*t1max){
		t1 = (-1)*t1max;
	}
	PID_PIT.DOUT =t1+t2+t3;
	PID_PIT.Ek_2=PID_PIT.Ek_1;
	PID_PIT.Ek_1=PID_PIT.Ek;
	
	
	moto1 =  moto1- PID_ROL.DOUT + PID_PIT.DOUT;
	moto2 =  moto2+ PID_ROL.DOUT + PID_PIT.DOUT;
	moto3 =  moto3- PID_ROL.DOUT + PID_PIT.DOUT;
	moto4 =  moto4- PID_ROL.DOUT - PID_PIT.DOUT;
	getMxMi(&moto1);
	getMxMi(&moto2);
	getMxMi(&moto3);
	getMxMi(&moto4);
	
    //if (1) Motor_1234(moto1, moto2, moto3, moto4);
	*pidcal20ms=0;
}

void LED_1234(u8 ctr8)
{
	if(ctr8==1)
	{
		LED1 = 1;
		LED2 = 0;
		LED3 = 0;
		LED4 = 0;
	}
	if(ctr8==2)
		{
		LED1 = 0;
		LED2 = 1;
		LED3 = 0;
		LED4 = 0;
	}
	if(ctr8==3)
		{
		LED1 = 0;
		LED2 = 0;
		LED3 = 1;
		LED4 = 0;
	}
	if(ctr8==4)
		{
		LED1 = 0;
		LED2 = 0;
		LED3 = 0;
		LED4 = 1;
	}
	if(ctr8==0)
		{
		LED1 = 0;
		LED2 = 0;
		LED3 = 0;
		LED4 = 0;
	}
}

void Light_Set(u8 light)//typical 35
{
	u8 LIGHT = 110;
	LIGHT = 110+light;
	if(LIGHT >= 180)
		LIGHT = 180;
	if(LIGHT <= 110)
		LIGHT = 110;
	TIM_SetCompare1(TIM4,LIGHT);
	TIM_SetCompare2(TIM4,LIGHT);
}
