#ifndef __CONTROL_H
#define __CONTROL_H
#include<sys.h>

typedef struct PID{float Kp,Ti,Td,DOUT,OUT,Ek,Ek_1,Ek_2;}PID;



void Motor_Init(void);
void Motor1_set(short speed);
void Motor2_set(short speed);
void Motor3_set(short speed);
void Motor4_set(short speed);
void Motor5_set(short speed);
void Motor6_set(short speed);
void Motor7_set(short speed);
void Motor8_set(short speed);
void Motor_1234(u8 UD,u8 speed);
void Motor_5678(u8 FB, u8 speed1, u8 LR, u8 speed2);
void PID_Calc(float roll, float pitch, u8* pidcal20ms);
void PID_Init(void);
void LED_1234(u8 ctr8);
void Light_Set(u8 light);

#endif
